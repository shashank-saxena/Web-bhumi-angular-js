<!DOCTYPE html>
<html>
<head>
	<title>Form</title>
</head>
<body>
<form method="post" action="http://localhost/testing/api/user">
	<input type="text" name="userEmail"/>
	<input type="password" name="userPass"/>
	<input type="submit" value="Submit">
</form>
</body>
</html>